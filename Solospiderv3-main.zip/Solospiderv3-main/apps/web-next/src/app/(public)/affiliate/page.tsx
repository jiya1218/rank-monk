"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { MarketingFooter } from "@/components/marketing/MarketingFooter";
import { 
  Award, ArrowRight, ShieldCheck, DollarSign, Users, 
  Target, BarChart3, HelpCircle, ChevronDown, Sparkles 
} from "lucide-react";

export default function AffiliateLandingPage() {
  const [isDark, setIsDark] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const saved = window.localStorage.getItem("solospider_theme");
      const nextDark = saved === "dark";
      setIsDark(nextDark);
      if (nextDark) {
        document.documentElement.classList.add("dark");
      } else {
        document.documentElement.classList.remove("dark");
      }
    }
  }, []);

  const toggleTheme = () => {
    const nextDark = !isDark;
    setIsDark(nextDark);
    window.localStorage.setItem("solospider_theme", nextDark ? "dark" : "light");
    if (nextDark) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  };



  const faqs = [
    {
      q: "How does the tracking work?",
      a: "When a visitor clicks your unique referral link, a tracking cookie is stored in their browser for 60 days. If they create an account and subscribe to any paid plan within that period, the sale is automatically attributed to you."
    },
    {
      q: "What is the minimum payout amount?",
      a: "The minimum payout threshold is $50. Once your approved earnings cross this limit, you can request a payout to your designated bank account or UPI address."
    },
    {
      q: "Can I refer my own accounts?",
      a: "No, self-referrals are strictly prohibited. Referrals must be unique external customers. Attempting to refer yourself or manipulate tracking will result in immediate suspension of your affiliate account."
    },
    {
      q: "How are commission payments processed?",
      a: "Commissions are recorded instantly. Once the referred subscriber's monthly billing cycle finishes successfully, the commission status shifts to Approved. Approved payouts are processed on a monthly basis upon request."
    }
  ];

  return (
    <div
      className="min-h-screen bg-[var(--bg)] text-[var(--ink)] flex flex-col font-sans transition-colors duration-300"
      style={
        {
          "--bg": isDark ? "#0e0c1a" : "#fbfaf7",
          "--bg-2": isDark ? "#141226" : "#f3f2eb",
          "--panel": isDark ? "#1c1a35" : "#ffffff",
          "--line": isDark ? "#252340" : "#e2e1da",
          "--ink": isDark ? "#ffffff" : "#000000",
          "--ink-2": isDark ? "#e2e8f0" : "#0f172a",
          "--muted": isDark ? "#94a3b8" : "#475569",
        } as React.CSSProperties
      }
    >
      {/* Custom Clean Affiliate Navbar */}
      <header className="sticky top-0 z-40 w-full border-b border-[var(--line)] bg-[var(--bg)]/80 backdrop-blur-md">
        <div className="max-w-[1240px] mx-auto px-7 h-[72px] flex items-center justify-between">
          <Link href="/affiliate" className="flex items-center gap-2.5 font-display font-extrabold text-[20px] tracking-tight shrink-0">
            <img src="/assets/solospider-logo.png" alt="Solo Spider" className={`h-[34px] w-auto block ${isDark ? "brightness-0 invert" : ""}`} />
            <span className="grad-text text-sm font-bold uppercase px-2 py-0.5 rounded-md bg-primary/10 tracking-widest border border-primary/20">Partners</span>
          </Link>

          <div className="hidden lg:flex items-center gap-8 text-sm font-bold text-[var(--muted)]">
            <a href="#benefits" className="hover:text-primary transition-colors">Program Benefits</a>
            <a href="#commissions" className="hover:text-primary transition-colors">Commission Matrix</a>
            <a href="#faq" className="hover:text-primary transition-colors">FAQ</a>
          </div>

          <div className="flex items-center gap-4">
            <button 
              onClick={toggleTheme}
              className="p-2 rounded-full hover:bg-[var(--bg-2)] text-[var(--ink)] cursor-pointer text-sm font-bold mr-1"
            >
              {isDark ? "☀️" : "🌙"}
            </button>
            <Link 
              href="/affiliate/login" 
              className="bg-[var(--bg-2)] hover:bg-[var(--line)] border border-[var(--line)] px-5 py-2.5 rounded-xl text-sm font-bold transition-all block text-[var(--ink)]"
            >
              Partner Login
            </Link>
            <Link 
              href="/affiliate/apply" 
              className="btn btn-grad px-5 py-2.5 rounded-xl text-sm font-bold block shadow-md shadow-primary/25"
            >
              Apply Now
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-grow pt-24">
        {/* Hero Section */}
        <section className="relative py-20 md:py-32 text-center overflow-hidden border-b border-[var(--line)]">
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-25 z-0">
            <div className="w-[900px] h-[900px] rounded-full border border-primary/20 flex items-center justify-center">
              <div className="w-[700px] h-[700px] rounded-full border border-primary/20 flex items-center justify-center">
                <div className="w-[500px] h-[500px] rounded-full border border-primary/25"></div>
              </div>
            </div>
          </div>

          <div className="max-w-[1240px] mx-auto px-7 relative z-10 text-center flex flex-col items-center justify-center">
            <span className="inline-flex items-center gap-2 py-1.5 px-4 rounded-full bg-primary/10 text-primary text-[12px] font-mono font-bold uppercase tracking-wider mb-5">
              🚀 Partner With Us
            </span>
            <h1 className="text-4xl md:text-[68px] font-black tracking-tight leading-[1.05] mb-6 max-w-[950px] mx-auto text-center">
              Earn <span className="grad-text">30% First Month + 15% Recurring</span> Commission
            </h1>
            <p className="text-[19px] text-[var(--muted)] max-w-[700px] mx-auto leading-relaxed mb-10 font-semibold text-center">
              Join the official SoloSpider Affiliate Program. Promote the AI Marketing OS, help businesses grow their digital presence, and earn 30% on their first purchase and 15% recurring lifetime commissions.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center w-full max-w-md">
              <Link 
                href="/affiliate/apply" 
                className="btn btn-grad px-8 py-4 text-sm font-bold shadow-lg shadow-primary/25 hover:scale-[1.02] transition-transform w-full sm:w-auto flex items-center justify-center gap-1.5 cursor-pointer"
              >
                Apply Now <ArrowRight className="w-4 h-4" />
              </Link>
              <Link 
                href="/affiliate/login" 
                className="btn btn-ghost border-[var(--line)] px-8 py-4 text-sm font-semibold hover:bg-[var(--bg-2)] w-full sm:w-auto flex items-center justify-center cursor-pointer"
              >
                Partner Dashboard
              </Link>
            </div>

            {/* Quick Stats Panel */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 w-full max-w-4xl mt-20 pt-10 border-t border-[var(--line)]">
              {[
                { title: "30% / 15%", desc: "First & Recurring Flat" },
                { title: "60 Days", desc: "Tracking Cookie Window" },
                { title: "$50 Threshold", desc: "Minimum Payout amount" },
                { title: "Monthly Payouts", desc: "Direct Bank & UPI Transfer" }
              ].map((item, idx) => (
                <div key={idx} className="text-center">
                  <h4 className="text-xl md:text-2xl font-black text-primary mb-1">{item.title}</h4>
                  <p className="text-xs text-[var(--muted)] font-semibold">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Why Partner with Us */}
        <section className="py-20 md:py-28 border-b border-[var(--line)]">
          <div className="max-w-[1240px] mx-auto px-7 text-center">
            <h2 className="text-3xl md:text-5xl font-black tracking-tight mb-16">
              Why Become a <span className="grad-text">SoloSpider Affiliate</span>?
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                {
                  title: "Generous Commissions",
                  desc: "Earn 30% first-month commission on new sales and 15% lifetime recurring commission on all customer renewals.",
                  icon: DollarSign
                },
                {
                  title: "High Conversion Rates",
                  desc: "SoloSpider is an all-in-one AI platform replacing multiple tools, making it easy to convert leads.",
                  icon: Target
                },
                {
                  title: "Real-time Analytics",
                  desc: "Track referral clicks, successful signups, subscription plans, and commission history in real-time.",
                  icon: BarChart3
                }
              ].map((item, idx) => {
                const Icon = item.icon;
                return (
                  <div key={idx} className="bg-[var(--panel)] border border-[var(--line)] rounded-3xl p-8 text-left hover:border-primary/30 transition-colors duration-300">
                    <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary mb-6">
                      <Icon className="w-6 h-6" />
                    </div>
                    <h3 className="text-xl font-bold mb-3">{item.title}</h3>
                    <p className="text-sm text-[var(--muted)] leading-relaxed font-semibold">{item.desc}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* How It Works */}
        <section className="py-20 md:py-28 border-b border-[var(--line)] bg-[var(--bg-2)]/30">
          <div className="max-w-[1000px] mx-auto px-7 text-center">
            <h2 className="text-3xl md:text-5xl font-black tracking-tight mb-16">
              How the Program Works
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-12 relative">
              {[
                { step: "01", title: "Join", desc: "Submit your registration application. Our partner success team reviews applications within 1-2 business days." },
                { step: "02", title: "Promote", desc: "Share your unique referral link across blogs, social media channels, email newsletters, and client networks." },
                { step: "03", title: "Earn", desc: "Receive lifetime commission payouts directly to your bank account or UPI every month your referrals remain active." }
              ].map((item, idx) => (
                <div key={idx} className="text-center relative flex flex-col items-center">
                  <span className="text-5xl font-black text-primary/15 font-mono mb-4 block">{item.step}</span>
                  <h4 className="text-xl font-bold mb-2">{item.title}</h4>
                  <p className="text-xs text-[var(--muted)] leading-relaxed font-semibold max-w-[280px]">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Commissions Breakout */}
        <section className="py-20 md:py-28 border-b border-[var(--line)]">
          <div className="max-w-[800px] mx-auto px-7 text-center">
            <h2 className="text-3xl md:text-5xl font-black tracking-tight mb-6">
              Commission Breakout
            </h2>
            <p className="text-sm text-[var(--muted)] font-semibold mb-12">
              See what you earn every month per client subscription referred:
            </p>

            <div className="border border-[var(--line)] rounded-3xl overflow-hidden shadow-sm bg-[var(--panel)]">
              <div className="grid grid-cols-3 bg-[var(--bg-2)] border-b border-[var(--line)] px-6 py-4 font-bold text-xs uppercase tracking-wider text-left text-[var(--ink)]">
                <span>Acquisition Stage</span>
                <span>Flat Commission Rate</span>
                <span>Example Earnings ($100 Sale)</span>
              </div>
              <div className="divide-y divide-[var(--line)] text-left text-sm font-semibold">
                {[
                  { stage: "First Month Acquisition", rate: "30% One-Time", example: "$30.00 first month" },
                  { stage: "Subsequent Months (Recurring)", rate: "15% Recurring", example: "$15.00 / month" }
                ].map((item, idx) => (
                  <div key={idx} className="grid grid-cols-3 px-6 py-4">
                    <span className="font-bold text-[var(--ink)]">{item.stage}</span>
                    <span className="text-[var(--muted)]">{item.rate}</span>
                    <span className="text-primary font-extrabold">{item.example}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Who Can Join */}
        <section className="py-20 md:py-28 border-b border-[var(--line)] bg-[var(--bg-2)]/30">
          <div className="max-w-[1240px] mx-auto px-7 text-center">
            <h2 className="text-3xl md:text-5xl font-black tracking-tight mb-16">
              Who Can Join the Program?
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { title: "Agencies & Consultants", desc: "Manage client projects and recommend SoloSpider to bundle website diagnostics." },
                { title: "Freelancers & Creators", desc: "Monetize your blogs, YouTube content, LinkedIn newsletters, and tutorials." },
                { title: "SEO Professionals", desc: "Help marketers explore modern Answer Engine Optimization diagnostics." },
                { title: "Affiliate Marketers", desc: "Drive structured campaigns and earn life-long recurring SaaS payouts." }
              ].map((item, idx) => (
                <div key={idx} className="bg-[var(--panel)] border border-[var(--line)] p-6 rounded-2xl text-left hover:border-primary/20 transition-colors">
                  <h4 className="font-bold text-sm text-primary uppercase tracking-widest mb-2">✦ {item.title}</h4>
                  <p className="text-xs text-[var(--muted)] leading-normal font-semibold">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Frequently Asked Questions */}
        <section className="py-20 md:py-28 border-b border-[var(--line)]">
          <div className="max-w-[800px] mx-auto px-7 text-center">
            <h2 className="text-3xl md:text-5xl font-black tracking-tight mb-16">
              Affiliate Program FAQs
            </h2>

            <div className="space-y-4 text-left">
              {faqs.map((faq, idx) => (
                <div 
                  key={idx} 
                  className="bg-[var(--panel)] border border-[var(--line)] rounded-2xl overflow-hidden cursor-pointer transition-all duration-300"
                  onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                >
                  <div className="flex items-center justify-between px-6 py-5 font-bold text-base select-none">
                    <span>{faq.q}</span>
                    <ChevronDown className={`w-5 h-5 text-[var(--muted)] transition-transform duration-300 ${openFaq === idx ? 'rotate-180' : ''}`} />
                  </div>
                  {openFaq === idx && (
                    <div className="px-6 pb-6 text-sm text-[var(--muted)] leading-relaxed font-semibold border-t border-[var(--line)]/50 pt-4 animate-fade-in">
                      {faq.a}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Apply Now CTA */}
        <section className="py-20 md:py-28 text-center bg-gradient-to-br from-indigo-500/10 to-purple-600/10 relative overflow-hidden">
          <div className="max-w-[800px] mx-auto px-7 relative z-10 flex flex-col items-center">
            <h2 className="text-3xl md:text-5xl font-black tracking-tight mb-4">
              Start Earning Today
            </h2>
            <p className="text-base text-[var(--muted)] font-semibold max-w-lg mb-8">
              Become a SoloSpider partner and join our mission to make website optimization and content operations simple.
            </p>
            <Link 
              href="/affiliate/apply" 
              className="btn btn-grad px-10 py-4 text-sm font-bold shadow-lg shadow-primary/25 hover:scale-[1.02] transition-transform flex items-center gap-1.5 cursor-pointer"
            >
              Apply to the Program <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </section>
      </main>

      <MarketingFooter />
    </div>
  );
}
