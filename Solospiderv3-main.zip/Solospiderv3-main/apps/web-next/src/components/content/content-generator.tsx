"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { getSupabaseBrowserClient } from "@/lib/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useProjects } from "@/hooks/useProjects";
import { toast } from "sonner";
import { Loader2, Sparkles, Image as ImageIcon, CheckCircle2, FileText, Fingerprint, Calendar as CalendarIcon } from "lucide-react";

export function ContentGenerator({ redirectBase = "/app/en/content" }: { redirectBase?: string }) {
  const router = useRouter();
  const { user } = useAuth();
  const { activeProjectId } = useProjects();
  const [loading, setLoading] = useState(false);
  const [generatingTitle, setGeneratingTitle] = useState(false);

  // Form State
  const [mainKeyword, setMainKeyword] = useState("");
  const [h1, setH1] = useState("");
  const [language, setLanguage] = useState("English (US)");
  const [articleType, setArticleType] = useState("Standard Blog Post");
  const [articleSize, setArticleSize] = useState("Medium (1000-1500 words)");
  const [researchLevel, setResearchLevel] = useState("Standard AI Search");
  const [tone, setTone] = useState("None");
  const [pointOfView, setPointOfView] = useState("None");
  const [textReadability, setTextReadability] = useState("None");
  const [targetCountry, setTargetCountry] = useState("United States");

  const [icp, setIcp] = useState("");
  const [brandVoice, setBrandVoice] = useState("none");
  const [details, setDetails] = useState("");
  const [secondaryKeywords, setSecondaryKeywords] = useState("");
  const [internalLinks, setInternalLinks] = useState("");
  const [scheduledDate, setScheduledDate] = useState("");

  const [selectedImageFile, setSelectedImageFile] = useState<File | null>(null);

  // Structure Settings
  const [structToc, setStructToc] = useState(false);
  const [structConclusion, setStructConclusion] = useState(true);
  const [structTables, setStructTables] = useState(true);
  const [structH3, setStructH3] = useState(true);
  const [structLists, setStructLists] = useState(true);
  const [structItalics, setStructItalics] = useState(true);
  const [structQuotes, setStructQuotes] = useState(true);
  const [structKeyTakeaways, setStructKeyTakeaways] = useState(true);
  const [structFaq, setStructFaq] = useState(true);
  const [structBold, setStructBold] = useState(true);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const effectiveProjectId = activeProjectId;
    if (!effectiveProjectId) {
      toast.error("Please select a project first.");
      return;
    }
    if (!mainKeyword || !h1) {
      toast.error("Please fill required fields (Keyword, Title)");
      return;
    }

    setLoading(true);
    try {
      const supabase = getSupabaseBrowserClient();

      // --- Plan-based blog limit check ---
      const { getPlanConfig } = await import("@/lib/services/projects");
      const { data: { user } } = await supabase.auth.getUser();
      let userPlan: import("@/types/project").PlanTier = "free";
      if (user?.email === "info@solospider.ai") {
        userPlan = "custom";
      } else {
        const subRes = await supabase
          .from("user_subscriptions" as any)
          .select("plan")
          .order("created_at", { ascending: false })
          .limit(1)
          .maybeSingle();
        userPlan = (subRes.data?.plan || "free") as import("@/types/project").PlanTier;
      }
      const planCfg = getPlanConfig(userPlan);

      if (planCfg.blogsPerMonth !== Infinity) {
        const now = new Date();
        const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
        const { count } = await supabase
          .from("content_items")
          .select("id", { count: "exact", head: true })
          .eq("project_id", effectiveProjectId)
          .gte("created_at", startOfMonth);
        
        if ((count ?? 0) >= planCfg.blogsPerMonth) {
          toast.error(`You've used all ${planCfg.blogsPerMonth} blog posts for this month. Upgrade your plan for unlimited blogs.`);
          setLoading(false);
          window.location.href = "/pricing";
          return;
        }
      }
      // --- End plan check ---


      // Map Article Size to word count target
      let wc = 1200;
      if (articleSize.includes("Small")) wc = 800;
      if (articleSize.includes("Medium")) wc = 1300;
      if (articleSize.includes("Large")) wc = 2200;

      let uploadedImageUrl = null;
      if (selectedImageFile) {
        const fileExt = selectedImageFile.name.split('.').pop();
        const fileName = `pregen-${Date.now()}-${Math.random()}.${fileExt}`;
        const { error: uploadError } = await supabase.storage
          .from('blog_images')
          .upload(fileName, selectedImageFile, { upsert: true });

        if (uploadError) {
          console.error("Storage upload error:", uploadError);
          throw new Error("Failed to upload image. Please ensure the 'blog_images' public storage bucket exists in Supabase.");
        }

        const { data: { publicUrl } } = supabase.storage
          .from('blog_images')
          .getPublicUrl(fileName);

        uploadedImageUrl = publicUrl;
      }

      const { data, error } = await supabase.from("content_items").insert({
        user_id: user!.id,
        project_id: effectiveProjectId,
        main_keyword: mainKeyword.trim(),
        secondary_keywords: secondaryKeywords ? secondaryKeywords.split(",").map(k => k.trim()) : [],
        word_count_target: wc,
        tone: tone !== "None" ? tone : "Professional",
        target_country: targetCountry,
        h1: h1.trim(),
        h2_list: [], // Auto-generated by the content pipeline now
        h3_list: [],
        internal_links: internalLinks ? internalLinks.split(",").map(k => k.trim()) : [],
        featured_image_url: uploadedImageUrl,
        details: details.trim() || null,
        scheduled_date: scheduledDate ? new Date(scheduledDate).toISOString() : null,
        status: "generating",
      }).select("id").single();

      if (error) throw error;

      const invokeRes = await fetch("/api/jobs/generate-blog", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          contentId: data.id,
          includeToc: structToc,
        }),
      }).catch((err: any) => {
        console.error("Generation invoke error:", err);
        return null;
      });

      if (!invokeRes || !invokeRes.ok) {
        toast.error("Failed to start generation background task");
      } else {
        toast.success("Generation started!");
      }
      router.push(`${redirectBase}/${data.id}`);
    } catch (err: any) {
      toast.error(err.message || "Failed to start generation");
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateTitle = async () => {
    if (!mainKeyword.trim()) {
      toast.error("Please enter a Main Keyword first");
      return;
    }
    setGeneratingTitle(true);
    try {
      const res = await fetch("/api/jobs/generate-title", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ keyword: mainKeyword.trim() }),
      });
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || `Server returned ${res.status}`);
      }
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      if (data.title) {
        setH1(data.title);
        toast.success("Title generated successfully");
      }
    } catch (err: any) {
      toast.error(err.message || "Failed to generate title");
    } finally {
      setGeneratingTitle(false);
    }
  };

  return (
    <div className="p-8 max-w-5xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-black flex items-center gap-2 text-slate-900">
            <span className="bg-indigo-500/10 text-indigo-600 p-2 rounded-xl">
              <FileText className="h-5 w-5" />
            </span>
            1-Click Blog Post
          </h1>
          <p className="text-slate-500 text-sm mt-1 ml-12 font-medium">Generate a high-quality article in 1 click.</p>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-xs font-bold bg-pink-500/10 text-pink-600 px-4 py-2 rounded-full flex items-center gap-1.5 border border-pink-500/20 uppercase tracking-wider">
            Cost: 1 Credit
          </span>
          <span className="text-xs font-bold bg-indigo-500/10 text-indigo-600 px-4 py-2 rounded-full flex items-center gap-1.5 border border-indigo-500/20 uppercase tracking-wider">
            <Sparkles className="h-4 w-4" /> 50 Credits Available
          </span>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Top Row: Keyword and Title */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-end">
          <div className="space-y-2">
            <label htmlFor="keyword" className="font-semibold text-slate-700 block text-sm">Main Keyword*</label>
            <input
              id="keyword"
              type="text"
              value={mainKeyword}
              onChange={(e) => setMainKeyword(e.target.value)}
              placeholder="Enter your main keyword"
              required
              className="w-full bg-white border border-slate-300 rounded-xl px-4 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500"
            />
          </div>
          <div className="space-y-2">
            <label htmlFor="h1" className="font-semibold text-slate-700 block text-sm">Title*</label>
            <div className="flex gap-2">
              <input
                id="h1"
                type="text"
                value={h1}
                onChange={(e) => setH1(e.target.value)}
                placeholder="Generate a title first"
                required
                className="flex-1 bg-white border border-slate-300 rounded-xl px-4 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500"
              />
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="w-[140px] bg-white border border-slate-300 rounded-xl px-2 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
              >
                <option value="English (US)">Eng (US)</option>
                <option value="English (UK)">Eng (UK)</option>
                <option value="Spanish">Spanish</option>
                <option value="French">French</option>
              </select>
              <button
                type="button"
                onClick={handleGenerateTitle}
                disabled={generatingTitle || !mainKeyword.trim()}
                className="shadow-sm bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold py-2 px-4 rounded-xl flex items-center gap-1.5 transition-all"
              >
                {generatingTitle ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
                {generatingTitle ? "Generating..." : "Generate a Title"}
              </button>
            </div>
          </div>
        </div>

        {/* Core Settings */}
        <div className="p-6 rounded-2xl border border-slate-200 bg-white shadow-sm shadow-slate-100 space-y-5">
          <h3 className="font-black text-lg text-slate-900 flex items-center gap-2">Core Settings</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700">Language</label>
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 font-medium"
              >
                <option value="English (US)">English (US)</option>
                <option value="English (UK)">English (UK)</option>
                <option value="Spanish">Spanish</option>
                <option value="French">French</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700">Article Type</label>
              <select
                value={articleType}
                onChange={(e) => setArticleType(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 font-medium"
              >
                <option value="Standard Blog Post">Standard Blog Post</option>
                <option value="How-to Guide">How-to Guide</option>
                <option value="Listicle">Listicle</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700">Article Size</label>
              <select
                value={articleSize}
                onChange={(e) => setArticleSize(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 font-medium"
              >
                <option value="Small (500-1000 words)">Small (500-1000 words)</option>
                <option value="Medium (1000-1500 words)">Medium (1000-1500 words)</option>
                <option value="Large (1500-2500 words)">Large (1500-2500 words)</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700">Research Level</label>
              <select
                value={researchLevel}
                onChange={(e) => setResearchLevel(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 font-medium"
              >
                <option value="Standard AI Search">Standard AI Search - 1 Cr</option>
                <option value="In-Depth Search">In-Depth Search - 2 Cr</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700">Tone of Voice</label>
              <select
                value={tone}
                onChange={(e) => setTone(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 font-medium"
              >
                <option value="None">None</option>
                <option value="Professional">Professional</option>
                <option value="Conversational">Conversational</option>
                <option value="Authoritative">Authoritative</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700">Point of View</label>
              <select
                value={pointOfView}
                onChange={(e) => setPointOfView(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 font-medium"
              >
                <option value="None">None</option>
                <option value="First Person (I/We)">First Person (I/We)</option>
                <option value="Second Person (You)">Second Person (You)</option>
                <option value="Third Person (They/It)">Third Person (They/It)</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700">Text Readability</label>
              <select
                value={textReadability}
                onChange={(e) => setTextReadability(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 font-medium"
              >
                <option value="None">None</option>
                <option value="7th Grade">7th Grade (Simple)</option>
                <option value="High School">High School</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700">Target Country</label>
              <select
                value={targetCountry}
                onChange={(e) => setTargetCountry(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 font-medium"
              >
                <option value="United States">United States</option>
                <option value="United Kingdom">United Kingdom</option>
                <option value="India">India</option>
                <option value="Australia">Australia</option>
              </select>
            </div>
          </div>
        </div>

        {/* Image Settings */}
        <div className="rounded-2xl border border-slate-200 bg-white shadow-sm shadow-slate-100 overflow-hidden">
          <div className="p-5 border-b border-slate-100 bg-slate-50/50 flex flex-col sm:flex-row items-center gap-3">
            <div className="h-12 w-12 flex-shrink-0 bg-indigo-500/10 border border-indigo-500/20 rounded-xl flex items-center justify-center">
              <ImageIcon className="h-5 w-5 text-indigo-600" />
            </div>
            <div>
              <h3 className="font-black text-slate-900 flex items-center gap-2 text-base">
                Image Settings
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-500/10 text-indigo-600 border border-indigo-500/25 font-bold uppercase">BETA</span>
              </h3>
              <p className="text-xs text-slate-500 font-semibold">Configure visual assets for your publication</p>
            </div>
          </div>
          <div className="p-8 text-center bg-white">
            <div className="max-w-md mx-auto space-y-3.5 text-left">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block">Custom Featured Image <span className="font-normal text-slate-500 font-semibold">(Optional)</span></label>
              {selectedImageFile ? (
                <div className="flex items-center justify-between bg-slate-50 border border-slate-250 rounded-xl p-3">
                  <span className="text-xs font-semibold text-slate-700 truncate max-w-[280px]">📄 {selectedImageFile.name}</span>
                  <button
                    type="button"
                    onClick={() => setSelectedImageFile(null)}
                    className="text-xs font-bold text-red-600 hover:text-red-800 cursor-pointer"
                  >
                    Remove
                  </button>
                </div>
              ) : (
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => setSelectedImageFile(e.target.files?.[0] || null)}
                  className="cursor-pointer bg-white border border-slate-300 w-full rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2"
                />
              )}
              <p className="text-[11px] text-slate-500 font-medium leading-relaxed">
                Upload a custom image to be used as the featured image for the blog. If left empty, an AI image can be generated depending on your plan.
              </p>
            </div>
          </div>
        </div>

        {/* ICP */}
        <div className="space-y-2">
          <label className="font-black flex items-center gap-2 text-slate-900 text-sm">
            Ideal Customer Profile (ICP)
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-500/10 text-indigo-600 border border-indigo-500/25 font-bold uppercase">New</span>
          </label>
          <div className="flex flex-col sm:flex-row gap-4">
            <textarea
              value={icp}
              onChange={(e) => setIcp(e.target.value)}
              placeholder="e.g., Marketing managers at B2B SaaS companies with 50-200 employees..."
              className="bg-white border border-slate-300 rounded-xl p-4 min-h-[80px] flex-1 font-semibold text-slate-950 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 text-sm"
            />
            <div className="bg-indigo-500/5 border border-indigo-500/20 rounded-2xl p-5 sm:w-[350px] flex items-start gap-3.5 text-xs text-slate-800 font-semibold leading-relaxed shadow-sm shadow-slate-100">
              <Fingerprint className="h-4 w-4 shrink-0 text-indigo-600" />
              <p>Define your ideal customer profile to tailor content tone, examples, and language that resonates with your target audience.</p>
            </div>
          </div>
        </div>

        {/* Brand Voice */}
        <div className="space-y-2">
          <label className="font-black text-slate-900 text-sm block">Brand Voice</label>
          <div className="flex flex-col sm:flex-row gap-4 items-start">
            <select
              value={brandVoice}
              onChange={(e) => setBrandVoice(e.target.value)}
              className="bg-white border border-slate-300 rounded-xl w-full sm:w-[250px] px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 font-semibold text-sm"
            >
              <option value="none">No brand kits found</option>
            </select>
            <div className="bg-indigo-500/5 border border-indigo-500/20 rounded-xl py-3 px-4 flex-1 flex items-center gap-2.5 text-xs text-slate-800 font-semibold leading-relaxed shadow-sm shadow-slate-100">
              <Fingerprint className="h-4 w-4 shrink-0 text-indigo-600" />
              <p>Create unique styles and tones for different situations using Brand Voice. Select a Brand Kit to apply it directly to the content.</p>
            </div>
          </div>
          <div className="pt-2">
            <p className="text-xs font-bold text-slate-500 mb-2">* Note: You have no active Brand Kits for this workspace.</p>
          </div>
        </div>

        {/* Structure Settings */}
        <div className="p-6 rounded-2xl border border-slate-200 bg-white shadow-sm shadow-slate-100 space-y-5">
          <h3 className="font-black text-lg text-slate-900">Structure Settings</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { label: "Table of Contents", value: structToc, setter: setStructToc },
              { label: "Conclusion", value: structConclusion, setter: setStructConclusion },
              { label: "Tables", value: structTables, setter: setStructTables },
              { label: "H3 Headings", value: structH3, setter: setStructH3 },
              { label: "Lists", value: structLists, setter: setStructLists },
              { label: "Italics", value: structItalics, setter: setStructItalics },
              { label: "Quotes", value: structQuotes, setter: setStructQuotes },
              { label: "Key Takeaways", value: structKeyTakeaways, setter: setStructKeyTakeaways },
              { label: "FAQ", value: structFaq, setter: setStructFaq },
              { label: "Bold", value: structBold, setter: setStructBold }
            ].map((struct) => (
              <div key={struct.label} className="flex flex-col gap-1.5 border-b border-slate-100 pb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-700">{struct.label}</span>
                <button
                  type="button"
                  onClick={() => struct.setter(!struct.value)}
                  className="flex items-center gap-2 text-sm font-bold w-full text-left text-slate-800 mt-1"
                >
                  <CheckCircle2 className={`h-4 w-4 rounded-full ${struct.value ? "text-indigo-600 bg-indigo-500/10" : "text-slate-400"}`} />
                  {struct.value ? "Yes" : "No"}
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Details to Include */}
        <div className="space-y-2">
          <label className="font-bold text-slate-700 block text-sm">
            Details to Include <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 font-normal">Optional</span>
          </label>
          <p className="text-xs text-slate-500">What details would you like to include in your article?</p>
          <textarea
            value={details}
            onChange={(e) => setDetails(e.target.value)}
            placeholder="e.g. phone number: +1 234-567-8900"
            className="w-full bg-white border border-slate-300 rounded-xl p-4 min-h-[100px] text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 text-sm"
          />
        </div>

        {/* SEO Keywords */}
        <div className="space-y-2">
          <label className="font-bold text-slate-700 block text-sm">
            SEO Keywords <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 font-normal">Optional</span>
          </label>
          <p className="text-xs text-slate-500">Keywords to include in the text.</p>
          <textarea
            value={secondaryKeywords}
            onChange={(e) => setSecondaryKeywords(e.target.value)}
            placeholder="Add a comma separated phrase"
            className="w-full bg-white border border-slate-300 rounded-xl p-4 min-h-[60px] text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 text-sm"
          />
        </div>

        {/* Scheduled Date */}
        <div className="space-y-2">
          <label className="font-bold text-slate-700 block text-sm">
            Scheduled Date <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 font-normal">Optional</span>
          </label>
          <p className="text-xs text-slate-500">When do you want this post to be scheduled for the content calendar?</p>
          <div className="flex items-center gap-2 w-full sm:w-[280px] bg-white border border-slate-300 rounded-xl px-4 py-2 text-slate-900 focus-within:ring-2 focus-within:ring-indigo-500/40">
            <CalendarIcon className="h-4 w-4 text-slate-400" />
            <input
              type="date"
              value={scheduledDate}
              onChange={(e) => setScheduledDate(e.target.value)}
              className="bg-transparent w-full focus:outline-none text-sm text-slate-900"
            />
          </div>
        </div>

        {/* Internal Links */}
        <div className="space-y-2">
          <label className="font-bold text-slate-700 block text-sm">
            Internal Links <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 font-normal">Optional</span>
          </label>
          <p className="text-xs text-slate-500">Provide comma-separated URLs or topics. The AI will weave these into the article automatically.</p>
          <textarea
            value={internalLinks}
            onChange={(e) => setInternalLinks(e.target.value)}
            placeholder="https://mysite.com/about, /pricing, https://mysite.com/blog/seo"
            className="w-full bg-white border border-slate-300 rounded-xl p-4 min-h-[60px] text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 text-sm"
          />
        </div>

        {/* Bottom Bar */}
        <div className="pt-6 border-t flex flex-col items-center gap-4">
          <span className="bg-indigo-500/5 text-indigo-600 border border-indigo-500/10 rounded-full font-bold px-4 py-1 text-xs">Estimated blog generation time: 5-10 minutes</span>
          <button
            type="submit"
            disabled={loading}
            className="w-[300px] bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-bold h-14 rounded-xl text-lg flex items-center justify-center shadow-lg transition-all"
          >
            {loading ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : null}
            Generate Blog Post
          </button>
        </div>
      </form>
    </div>
  );
}
